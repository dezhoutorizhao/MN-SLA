# HARD V3 Raw-vs-Wrapped Attenuation

This report is a paired attenuation analysis, not a leaderboard.
Positive values mean the post-hoc/test-time matched-neutral estimator reduced the corresponding raw HARD V3 paired mean gap.
It must not be described as single-pass robustness, trained PACT, deployable-model SOTA, or an equal-cost comparison against raw one-pass baselines.
Support is positive paired mean attenuation, not majority-base improvement.

- name: dynaguard_pku2k_core_only_all_2000_raw_vs_cf_cycle_v1
- threshold: 0.500000
- raw primary attack samples: 64000
- wrapped primary attack samples: 63992
- paired primary attack samples: 63992
- paired bases: 2000
- duplicate raw primary attack ids: 0
- duplicate wrapped primary attack ids: 0
- unpaired raw primary attack ids: 8
- unpaired wrapped primary attack ids: 0
- base id mismatches: 0
- dropped primary attack pairs: 8

## Attenuation Inference

- primary_error_gap_attenuation: n=2000, mean=0.117676, ci95=[0.107539, 0.127483], p_mean_gt_0=0.000100
- clean_correct_flip_attenuation: n=1650, mean=0.133982, ci95=[0.122253, 0.145310], p_mean_gt_0=0.000100
- adverse_prob_drift_attenuation: n=2000, mean=0.117676, ci95=[0.107291, 0.128134], p_mean_gt_0=0.000100

## Base-Level Distribution

- primary_error_gap_attenuation: n=2000, mean=0.117676, median=0.000000, trimmed_mean_10pct=0.060142, positive=542, zero=1455, negative=3
- clean_correct_flip_attenuation: n=1650, mean=0.133982, median=0.000000, trimmed_mean_10pct=0.077871, positive=510, zero=1138, negative=2
- adverse_prob_drift_attenuation: n=2000, mean=0.117676, median=0.000000, trimmed_mean_10pct=0.060142, positive=542, zero=1455, negative=3

Interpret attenuation claims as paired mean effects. Do not imply that most bases improved unless the positive/zero/negative counts support that stronger statement.
