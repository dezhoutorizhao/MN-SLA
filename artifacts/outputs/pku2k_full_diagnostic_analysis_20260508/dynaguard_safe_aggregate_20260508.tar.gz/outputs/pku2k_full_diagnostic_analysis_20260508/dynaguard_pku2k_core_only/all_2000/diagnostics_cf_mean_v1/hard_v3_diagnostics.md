# HARD V3 Diagnostics

- records: 85992
- bases: 2000
- primary scope: `primary_attack_average_effect`
- primary attack records: 63992
- primary matched-neutral missing rate: 0.000000

## Primary Average Effects

- primary_attack_minus_matched_neutral_error: n=2000, mean=0.006577, ci95=[0.005077, 0.008077], p_mean_gt_0=0.000100
- primary_attack_clean_correct_excess_flip_over_matched_neutral: n=1650, mean=0.005775, ci95=[0.004176, 0.007520], p_mean_gt_0=0.000100
- primary_attack_prob_drift_vs_matched_neutral: n=2000, mean=-0.000088, ci95=[-0.000204, 0.000000], p_mean_gt_0=1.000000

## Stress Diagnostics

- stress_worst_attack_excess_error_over_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
- stress_clean_correct_any_excess_flip_over_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
