# HARD V3 Diagnostics

- records: 86000
- bases: 2000
- primary scope: `primary_attack_average_effect`
- primary attack records: 64000
- primary matched-neutral missing rate: 0.000000

## Primary Average Effects

- primary_attack_minus_matched_neutral_error: n=2000, mean=0.117500, ci95=[0.107561, 0.127267], p_mean_gt_0=0.000100
- primary_attack_clean_correct_excess_flip_over_matched_neutral: n=1650, mean=0.133769, ci95=[0.121212, 0.145739], p_mean_gt_0=0.000100
- primary_attack_prob_drift_vs_matched_neutral: n=2000, mean=0.117563, ci95=[0.107616, 0.127345], p_mean_gt_0=0.000100

## Stress Diagnostics

- stress_worst_attack_excess_error_over_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
- stress_clean_correct_any_excess_flip_over_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
