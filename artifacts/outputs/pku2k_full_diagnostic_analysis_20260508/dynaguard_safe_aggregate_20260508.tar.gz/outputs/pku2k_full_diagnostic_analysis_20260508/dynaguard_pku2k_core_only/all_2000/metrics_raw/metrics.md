# Evaluation Metrics

## Overall

- n: 86000.000000
- accuracy: 0.717000
- precision: 0.661011
- recall: 0.997444
- f1: 0.795104
- auprc: 0.660803
- auroc: 0.685596
- ece: 0.282936
- mean_prob_unsafe: 0.830622

## Flip Rates

- harmful_to_safe_attack_flip_rate: 0.002611
- benign_to_unsafe_attack_flip_rate: 0.504724
- harmful_to_safe_attack_error_rate: 0.002611
- benign_to_unsafe_attack_error_rate: 0.695495
- clean_to_pressure_pred_flip_rate: 0.140906
- mean_clean_to_pressure_prob_drift: 0.140875

## Pressure Degradation

- n_base_with_clean_and_pressure: 2000.000000
- n_base_with_pressure_and_neutral: 2000.000000
- n_base_with_attack_and_neutral: 2000.000000
- n_clean_correct_with_attack: 1650.000000
- n_clean_correct_with_attack_and_neutral: 1650.000000
- pressure_minus_clean_error: 0.139063
- pressure_minus_neutral_error: 0.119662
- attack_minus_neutral_error: 0.119662
- clean_correct_attack_flip: 0.325455
- clean_correct_neutral_flip: 0.069091
- clean_correct_attack_excess_flip_over_neutral: 0.256364
- mean_attack_prob_drift_vs_clean: 0.139031
- mean_attack_prob_drift_vs_neutral: 0.119706
- worst_attack_excess_error_over_neutral: 0.249100

## Pressure Degradation Inference

- attack_minus_neutral_error: n=2000, mean=0.119662, ci95=[0.109625, 0.129595], p_mean_gt_0=0.000100
- pressure_minus_neutral_error: n=2000, mean=0.119662, ci95=[0.109669, 0.129914], p_mean_gt_0=0.000100
- pressure_minus_clean_error: n=2000, mean=0.139063, ci95=[0.126953, 0.151345], p_mean_gt_0=0.000100
- clean_correct_attack_excess_flip_over_neutral: n=1650, mean=0.256364, ci95=[0.236348, 0.276985], p_mean_gt_0=0.000100
- worst_attack_excess_error_over_neutral: n=2000, mean=0.249100, ci95=[0.231100, 0.267152], p_mean_gt_0=0.000100
- mean_attack_prob_drift_vs_neutral: n=2000, mean=0.119706, ci95=[0.109345, 0.130015], p_mean_gt_0=0.000100
- mean_attack_prob_drift_vs_clean: n=2000, mean=0.139031, ci95=[0.126820, 0.151023], p_mean_gt_0=0.000100

## Clean vs Pressure

- clean: n=2000, f1=0.862853, ece=0.175000
- pressure: n=64000, f1=0.777606, ece=0.314000
- pressure_attack: n=64000, f1=0.777606, ece=0.314000
- neutral_control: n=20000, f1=0.849594, ece=0.194325

## By Pressure Type

- authority: n=8000, f1=0.768881, ece=0.329750
- clean: n=2000, f1=0.862853, ece=0.175000
- consistency: n=8000, f1=0.805316, ece=0.265500
- flattery: n=8000, f1=0.762343, ece=0.342375
- identity: n=8000, f1=0.760059, ece=0.346688
- majority: n=8000, f1=0.769150, ece=0.329562
- neutral_careful_review: n=10000, f1=0.849169, ece=0.194950
- neutral_format_reminder: n=10000, f1=0.850019, ece=0.193700
- pity: n=8000, f1=0.800073, ece=0.274375
- reciprocity: n=8000, f1=0.776011, ece=0.317000
- stacked_authority_consistency: n=8000, f1=0.781525, ece=0.306875

## By Attack Pressure Type

- authority: n=8000, f1=0.768881, ece=0.329750
- consistency: n=8000, f1=0.805316, ece=0.265500
- flattery: n=8000, f1=0.762343, ece=0.342375
- identity: n=8000, f1=0.760059, ece=0.346688
- majority: n=8000, f1=0.769150, ece=0.329562
- pity: n=8000, f1=0.800073, ece=0.274375
- reciprocity: n=8000, f1=0.776011, ece=0.317000
- stacked_authority_consistency: n=8000, f1=0.781525, ece=0.306875

## By Pressure Family

- authority: n=8000, f1=0.768881, ece=0.329750
- consistency: n=8000, f1=0.805316, ece=0.265500
- flattery: n=8000, f1=0.762343, ece=0.342375
- identity: n=8000, f1=0.760059, ece=0.346688
- majority: n=8000, f1=0.769150, ece=0.329562
- pity: n=8000, f1=0.800073, ece=0.274375
- reciprocity: n=8000, f1=0.776011, ece=0.317000
- stacked: n=8000, f1=0.781525, ece=0.306875
