# HARD V3 Raw-vs-Wrapped Attenuation

This report is a paired attenuation analysis, not a leaderboard.
Positive values mean the post-hoc/test-time matched-neutral estimator reduced the corresponding raw HARD V3 paired mean gap.
It must not be described as single-pass robustness, trained PACT, deployable-model SOTA, or an equal-cost comparison against raw one-pass baselines.
Support is positive paired mean attenuation, not majority-base improvement.

- name: dynaguard_pku2k_core_only_balanced_1798_raw_vs_cf_mean_v1
- threshold: 0.500000
- raw primary attack samples: 57536
- wrapped primary attack samples: 57528
- paired primary attack samples: 57528
- paired bases: 1798
- duplicate raw primary attack ids: 0
- duplicate wrapped primary attack ids: 0
- unpaired raw primary attack ids: 8
- unpaired wrapped primary attack ids: 0
- base id mismatches: 0
- dropped primary attack pairs: 8

## Attenuation Inference

- primary_error_gap_attenuation: n=1798, mean=0.123386, ci95=[0.113490, 0.134348], p_mean_gt_0=0.000100
- clean_correct_flip_attenuation: n=1448, mean=0.145850, ci95=[0.133542, 0.158999], p_mean_gt_0=0.000100
- adverse_prob_drift_attenuation: n=1798, mean=0.130896, ci95=[0.120167, 0.142166], p_mean_gt_0=0.000100

## Base-Level Distribution

- primary_error_gap_attenuation: n=1798, mean=0.123386, median=0.000000, trimmed_mean_10pct=0.067975, positive=526, zero=1263, negative=9
- clean_correct_flip_attenuation: n=1448, mean=0.145850, median=0.000000, trimmed_mean_10pct=0.092491, positive=501, zero=940, negative=7
- adverse_prob_drift_attenuation: n=1798, mean=0.130896, median=0.000000, trimmed_mean_10pct=0.074659, positive=542, zero=1253, negative=3

Interpret attenuation claims as paired mean effects. Do not imply that most bases improved unless the positive/zero/negative counts support that stronger statement.
