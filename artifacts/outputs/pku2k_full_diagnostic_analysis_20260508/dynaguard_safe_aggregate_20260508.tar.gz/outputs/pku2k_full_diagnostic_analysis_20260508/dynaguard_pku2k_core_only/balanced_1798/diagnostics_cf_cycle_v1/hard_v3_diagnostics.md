# HARD V3 Diagnostics

- records: 77306
- bases: 1798
- primary scope: `primary_attack_average_effect`
- primary attack records: 57528
- primary matched-neutral missing rate: 0.000000

## Primary Average Effects

- primary_attack_minus_matched_neutral_error: n=1798, mean=-0.000195, ci95=[-0.000453, 0.000000], p_mean_gt_0=1.000000
- primary_attack_clean_correct_excess_flip_over_matched_neutral: n=1448, mean=-0.000242, ci95=[-0.000563, 0.000000], p_mean_gt_0=1.000000
- primary_attack_prob_drift_vs_matched_neutral: n=1798, mean=-0.000098, ci95=[-0.000227, 0.000000], p_mean_gt_0=1.000000

## Stress Diagnostics

- stress_worst_attack_excess_error_over_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
- stress_clean_correct_any_excess_flip_over_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
