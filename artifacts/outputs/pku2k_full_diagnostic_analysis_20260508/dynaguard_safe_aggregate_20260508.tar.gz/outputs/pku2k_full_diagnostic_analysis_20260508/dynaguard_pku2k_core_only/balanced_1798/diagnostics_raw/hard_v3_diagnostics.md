# HARD V3 Diagnostics

- records: 77314
- bases: 1798
- primary scope: `primary_attack_average_effect`
- primary attack records: 57536
- primary matched-neutral missing rate: 0.000000

## Primary Average Effects

- primary_attack_minus_matched_neutral_error: n=1798, mean=0.130701, ci95=[0.119889, 0.141999], p_mean_gt_0=0.000100
- primary_attack_clean_correct_excess_flip_over_matched_neutral: n=1448, mean=0.152430, ci95=[0.139870, 0.164884], p_mean_gt_0=0.000100
- primary_attack_prob_drift_vs_matched_neutral: n=1798, mean=0.130770, ci95=[0.119933, 0.142112], p_mean_gt_0=0.000100

## Stress Diagnostics

- stress_worst_attack_excess_error_over_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
- stress_clean_correct_any_excess_flip_over_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
