# HARD V3 Evidence Ledger

Primary summaries use only core attack records with `claim_scope=primary_attack_average_effect`.
Matched neutral controls are selected within the same base by `(pressure_layout, pressure_format)`.
Stress-bank summaries are diagnostic only and must not be described as average causal effects.

## dynaguard_pku2k_core_only_raw

- records: 77314
- bases: 1798
- primary attack records: 57536
- primary matched-neutral missing rate: 0.000000

### Primary

- n_bases: 1798
- n_attack_records: 57536
- mean_attack_minus_matched_neutral_error: 0.130701
- inference_attack_minus_matched_neutral_error: n=1798, mean=0.130701, ci95=[0.118933, 0.141877], p_mean_gt_0=0.000200
- mean_clean_correct_excess_flip_over_matched_neutral: 0.152430
- inference_clean_correct_excess_flip_over_matched_neutral: n=1448, mean=0.152430, ci95=[0.139976, 0.165838], p_mean_gt_0=0.000200
- mean_adverse_prob_drift_vs_matched_neutral: 0.130770
- inference_adverse_prob_drift_vs_matched_neutral: n=1798, mean=0.130770, ci95=[0.118959, 0.141905], p_mean_gt_0=0.000200

### Slices

#### label_name
- safe: n_bases=899, n_attack=28768, error_gap=0.261402, clean_correct_flip=0.402038, prob_drift=0.261506
- unsafe: n_bases=899, n_attack=28768, error_gap=0.000000, clean_correct_flip=0.000000, prob_drift=0.000035

#### pressure_family
- authority: n_bases=1798, n_attack=7192, error_gap=0.148568, clean_correct_flip=0.174896, prob_drift=0.148394
- consistency: n_bases=1798, n_attack=7192, error_gap=0.076682, clean_correct_flip=0.086671, prob_drift=0.076787
- flattery: n_bases=1798, n_attack=7192, error_gap=0.162194, clean_correct_flip=0.191298, prob_drift=0.162298
- identity: n_bases=1798, n_attack=7192, error_gap=0.166922, clean_correct_flip=0.196996, prob_drift=0.167095
- majority: n_bases=1798, n_attack=7192, error_gap=0.148012, clean_correct_flip=0.173343, prob_drift=0.148046
- pity: n_bases=1798, n_attack=7192, error_gap=0.086555, clean_correct_flip=0.098066, prob_drift=0.086659
- reciprocity: n_bases=1798, n_attack=7192, error_gap=0.133968, clean_correct_flip=0.156250, prob_drift=0.134073
- stacked: n_bases=1798, n_attack=7192, error_gap=0.122706, clean_correct_flip=0.141920, prob_drift=0.122810

#### pressure_layout
- post_case: n_bases=1798, n_attack=14384, error_gap=0.190211, clean_correct_flip=0.229541, prob_drift=0.190211
- pre_case: n_bases=1798, n_attack=14384, error_gap=0.108940, clean_correct_flip=0.127158, prob_drift=0.109219
- sandwich: n_bases=1798, n_attack=14384, error_gap=0.138626, clean_correct_flip=0.159012, prob_drift=0.138626
- transcript: n_bases=1798, n_attack=14384, error_gap=0.085025, clean_correct_flip=0.094009, prob_drift=0.085025

#### target_direction
- toward_safe: n_bases=899, n_attack=28768, error_gap=0.000000, clean_correct_flip=0.000000, prob_drift=0.000035
- toward_unsafe: n_bases=899, n_attack=28768, error_gap=0.261402, clean_correct_flip=0.402038, prob_drift=0.261506

#### clean_correct
- False: n_bases=350, n_attack=11200, error_gap=0.040804, clean_correct_flip=nan, prob_drift=0.040804
- True: n_bases=1448, n_attack=46336, error_gap=0.152430, clean_correct_flip=0.152430, prob_drift=0.152516

### Stress Diagnostic Only

- n_bases: 0
- n_attack_records: 0
- mean_attack_minus_matched_neutral_error: nan
- inference_attack_minus_matched_neutral_error: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
- mean_clean_correct_excess_flip_over_matched_neutral: nan
- inference_clean_correct_excess_flip_over_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
- mean_adverse_prob_drift_vs_matched_neutral: nan
- inference_adverse_prob_drift_vs_matched_neutral: n=0, mean=nan, ci95=[nan, nan], p_mean_gt_0=nan
