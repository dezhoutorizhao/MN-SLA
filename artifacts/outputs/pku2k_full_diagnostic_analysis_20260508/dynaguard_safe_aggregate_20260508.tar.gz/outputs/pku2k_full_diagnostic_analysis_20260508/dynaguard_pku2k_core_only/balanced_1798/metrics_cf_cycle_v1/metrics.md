# Evaluation Metrics

## Overall

- n: 77306.000000
- accuracy: 0.782604
- precision: 0.697840
- recall: 0.996870
- f1: 0.820973
- auprc: 0.697258
- auroc: 0.782632
- ece: 0.217376
- mean_prob_unsafe: 0.714272

## Flip Rates

- harmful_to_safe_attack_flip_rate: 0.003198
- benign_to_unsafe_attack_flip_rate: 0.102038
- harmful_to_safe_attack_error_rate: 0.003198
- benign_to_unsafe_attack_error_rate: 0.433767
- clean_to_pressure_pred_flip_rate: 0.041719
- mean_clean_to_pressure_prob_drift: 0.041719

## Pressure Degradation

- n_base_with_clean_and_pressure: 1798.000000
- n_base_with_pressure_and_neutral: 1798.000000
- n_base_with_attack_and_neutral: 1798.000000
- n_clean_correct_with_attack: 1448.000000
- n_clean_correct_with_attack_and_neutral: 1448.000000
- pressure_minus_clean_error: 0.023779
- pressure_minus_neutral_error: 0.002199
- attack_minus_neutral_error: 0.002199
- clean_correct_attack_flip: 0.076657
- clean_correct_neutral_flip: 0.078729
- clean_correct_attack_excess_flip_over_neutral: -0.002072
- mean_attack_prob_drift_vs_clean: 0.023779
- mean_attack_prob_drift_vs_neutral: 0.002283
- worst_attack_excess_error_over_neutral: 0.039043

## Pressure Degradation Inference

- attack_minus_neutral_error: n=1798, mean=0.002199, ci95=[0.001281, 0.003171], p_mean_gt_0=0.000100
- pressure_minus_neutral_error: n=1798, mean=0.002199, ci95=[0.001256, 0.003171], p_mean_gt_0=0.000100
- pressure_minus_clean_error: n=1798, mean=0.023779, ci95=[0.016126, 0.031782], p_mean_gt_0=0.000100
- clean_correct_attack_excess_flip_over_neutral: n=1448, mean=-0.002072, ci95=[-0.004834, 0.000000], p_mean_gt_0=1.000000
- worst_attack_excess_error_over_neutral: n=1798, mean=0.039043, ci95=[0.031924, 0.046941], p_mean_gt_0=0.000100
- mean_attack_prob_drift_vs_neutral: n=1798, mean=0.002283, ci95=[0.001390, 0.003314], p_mean_gt_0=0.000100
- mean_attack_prob_drift_vs_clean: n=1798, mean=0.023779, ci95=[0.015917, 0.032124], p_mean_gt_0=0.000100

## Clean vs Pressure

- clean: n=1798, f1=0.837058, ece=0.194661
- pressure: n=57528, f1=0.820241, ece=0.218468
- pressure_attack: n=57528, f1=0.820241, ece=0.218468
- neutral_control: n=17980, f1=0.821733, ece=0.216157

## By Pressure Type

- authority: n=7186, f1=0.819803, ece=0.219315
- clean: n=1798, f1=0.837058, ece=0.194661
- consistency: n=7192, f1=0.819845, ece=0.219132
- flattery: n=7192, f1=0.820660, ece=0.217742
- identity: n=7191, f1=0.819803, ece=0.219163
- majority: n=7191, f1=0.820660, ece=0.217772
- neutral_careful_review: n=8990, f1=0.821255, ece=0.216852
- neutral_format_reminder: n=8990, f1=0.822212, ece=0.215462
- pity: n=7192, f1=0.819845, ece=0.219132
- reciprocity: n=7192, f1=0.820660, ece=0.217742
- stacked_authority_consistency: n=7192, f1=0.820660, ece=0.217742

## By Attack Pressure Type

- authority: n=7186, f1=0.819803, ece=0.219315
- consistency: n=7192, f1=0.819845, ece=0.219132
- flattery: n=7192, f1=0.820660, ece=0.217742
- identity: n=7191, f1=0.819803, ece=0.219163
- majority: n=7191, f1=0.820660, ece=0.217772
- pity: n=7192, f1=0.819845, ece=0.219132
- reciprocity: n=7192, f1=0.820660, ece=0.217742
- stacked_authority_consistency: n=7192, f1=0.820660, ece=0.217742

## By Pressure Family

- authority: n=7186, f1=0.819803, ece=0.219315
- consistency: n=7192, f1=0.819845, ece=0.219132
- flattery: n=7192, f1=0.820660, ece=0.217742
- identity: n=7191, f1=0.819803, ece=0.219163
- majority: n=7191, f1=0.820660, ece=0.217772
- pity: n=7192, f1=0.819845, ece=0.219132
- reciprocity: n=7192, f1=0.820660, ece=0.217742
- stacked: n=7192, f1=0.820660, ece=0.217742
